<?php

return [
	'administration' => 'Administration',
	'home' => 'Retour sur site',
	'logout' => 'Se déconnecter',
	'dashboard' => 'Tableau de bord',
	'users' => 'utilisateurs',
	'see-all' => 'Voir tout',
	'add' => 'Ajouter',
	'new-registers' => 'New users !',
	'packages' => 'Packages',
	'subscriptions' => 'Abonnements',
	'my-profile' => 'My Profile',
	'customers' => 'Les clients',
	'all-users' => 'All users'
];
