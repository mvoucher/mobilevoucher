<?php

return [
	'send' => 'envoyer',
	'continue' => 'continuer',
	'update' => 'mettre à jour'
];
