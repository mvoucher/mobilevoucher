<?php

return [
	'email-title' => 'Account creation',
	'email-intro'=> 'To create an account with M-Voucher 3, ',
	'email-link' => 'click on this link'

];

