<?php

return [
	'send' => 'Send',
	'continue' => 'Continue',
	'update' => 'Update'
];
