<?php

return [
	'view-more' => 'View More',
	'subscribe' => 'Subscribe'
];
