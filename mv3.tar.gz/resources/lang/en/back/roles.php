<?php

return [
	'dashboard' => 'Roles gestion',
	'roles' => 'Roles',
	'admin' => 'Title for administrators',
	'user' => 'Title for users',
	'ok' => 'Roles updated.'
];