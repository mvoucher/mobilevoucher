<?php

return [
	'administration' => 'Administration',
	'home' => 'Back on site',
	'logout' => 'Logout',
	'dashboard' => 'Dashboard',
	'users' => 'users',
	'see-all' => 'See all',
	'add' => 'Add',
	'new-registers' => 'New users !',
	'new-posts' => 'New posts !',
	'new-comments' => 'New comments !',
	'packages' => 'Packages',
	'subscriptions' => 'Subscriptions',
	'my-profile' => 'My Profile',
	'customers' => 'Customers',
	'all-users' => 'All users'
];
