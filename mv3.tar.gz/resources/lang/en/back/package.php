<?php

return [
	'list' => 'List of Packages',
	'packages' => 'Packages',
	'subscribers' => 'Subscribers',
	'add' => 'Add',
	'name' => 'Package name',
	'fee' => 'Subscription fee',
	'type' => 'Period of subscription',
	'details' => 'Package description',
	'created'=>'Package successfully created',
	'destroyed'=>'Package successfully deleted',
	'updated'=>'Package successfully updated',
	'destroy-warning' => 'Do you want to delete package?'
	];