@extends('template')

@section('styles')	

@stop

@section('main')
<?php $page_name = 'Generate Vouchers' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title">{{-- ..... --}}</h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="{{ url('voucher_prog_batches') }}">List generated vouchers</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->
					
					<!--form goes here -->
						{!! Form::open(['url' => 'invite_organ', 'method' => 'post', 'class' => 'form-horizontal']) !!}	
							

							<div class="form-group">
							{!! Form::label('type', 'Select voucher type', ['class' => 'col-sm-3 control-label'] )  !!}
								<div class="col-sm-5">
							<select class="form-control select2_1" name="type">						
							<option value="AL">Cereal</option>
							<option value="AR">Legume</option>
					</select>								
								</div>
								<span class="text-danger">{{ $errors->first('type', ':message') }}</span>
							</div>

							<div class="form-group">
							{!! Form::label('number', 'Number of vouchers', ['class' => 'col-sm-3 control-label'] )  !!}
								<div class="col-sm-5">
							{{ Form::text('number', null, ['class' => 'form-control','placeholder'=>'0']) }}
								</div>
								<span class="text-danger">{{ $errors->first('number', ':message') }}</span>
							</div>

							<div class="form-group margin-bottom-0">
								<div class="col-sm-offset-3 col-sm-10">
									{!! Form::submit('Generate Vouchers',null,'btn btn-info btn-sm ml-15') !!}
								</div>
							</div>

				  {!! Form::close() !!}

				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>


@stop

@section('scripts')

	<!-- Demo Scripts -->
	{!! HTML::script('assets/scripts/form.demo.min.js') !!}	
@stop

