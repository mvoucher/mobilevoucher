@extends('template')

@include('partials/dtables')

@section('styles')	
	@yield('dtstyles')

		<!-- FlexDatalist -->
		{!! HTML::style('assets/plugin/flexdatalist/jquery.flexdatalist.min.css') !!}	

	<!-- Popover -->
	{!! HTML::style('assets/plugin/popover/jquery.popSelect.min.css') !!}

	<!-- Select2 -->
	{!! HTML::style('assets/plugin/select2/css/select2.min.css') !!}	
@stop

@section('main')
<?php $page_name = 'Implemented Voucher Types' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title">{{-- ..... --}}</h4>
					<!-- /.box-title -->
										
					<!--form goes here -->
						{!! Form::open(['url' => 'voucher_implement_type', 'method' => 'post', 'class' => 'form-horizontal']) !!}	
					

							<div class="form-group">
							{!! Form::label('types', 'Choose Voucher Types', ['class' => 'col-sm-3 control-label'] )  !!}
								<div class="col-sm-5">

							<select class="form-control select2_1" name="vouchertype_id">						
							@foreach ($voucher_types as $voucher_types)
						<option value="{{ $voucher_types->id }}">{{ $voucher_types->name }}({{ $voucher_types->value }})</option>
							@endforeach
					</select>
								<span class="text-danger">{{ $errors->first('vouchertype_id', ':message') }}</span>	
					</div>
					<div class="col-sm-4">
						{!! Form::submit('Update list',null,'btn btn-info btn-sm ml-15') !!}
					</div>
							</div>

	{!! Form::text('org_id', auth()->user()->org_id, ['class' => 'hpet']) !!}
    {!! Form::text('user_id', auth()->user()->id, ['class' => 'hpet']) !!}

				  {!! Form::close() !!}

				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title">{{-- ..... --}}</h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="{{ route('voucher.create') }}">Create New Type</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->

									 @if(session()->has('ok'))
    @include('partials/error', ['type' => 'success', 'message' => session('ok')])
  @endif

					<table id="example" class="table table-striped table-bordered display" style="width:100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Color</th>
								<th>Value</th>
								<th>View : Edit</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
						@foreach ($imp_voucher as $imp)
							<tr>
								<td>{{ $imp->vouchertype_id }}</td>
								<td>....</td>
								<td>....</td>
								<td>   
								<div class="btn-group">
						 <a class="btn btn-primary btn-xs" href="#"><i class="fa fa-eye" title="View more"></i></a>
						<a class="btn btn-warning btn-xs" href="#"><i class="fa fa-edit" title="Edit"></i></a>
								</div></td>
								<td>
		{!! Form::open(['method' => 'DELETE', 'route' => ['user.destroy', 1]]) !!}
        {!! Form::destroy('Delete', 'Are you sure you want to delete this voucher type') !!}
        {!! Form::close() !!}
								</td>
							</tr>
						@endforeach
							
						</tbody>
					</table>
				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>




@stop

@section('scripts')
	@yield('dtscripts')

	 <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: [ 0, ':visible' ]
                }
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdfHtml5',
                exportOptions: {
                    columns: [ 0, 1, 2, 3]
                }
            },
            'colvis'
        ]
    } );
} );
    </script>
<!-- Flex Datalist -->
	{!! HTML::script('assets/plugin/flexdatalist/jquery.flexdatalist.min.js') !!}

	<!-- Popover -->
	{!! HTML::script('assets/plugin/popover/jquery.popSelect.min.js') !!}

	<!-- Select2 -->
	{!! HTML::script('assets/plugin/select2/js/select2.min.js') !!}

	<!-- Multi Select -->
	{!! HTML::script('assets/plugin/multiselect/multiselect.min.js') !!}

	<!-- Demo Scripts -->
	{!! HTML::script('assets/scripts/form.demo.min.js') !!}

@stop



