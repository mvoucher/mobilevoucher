@extends('template')


@section('styles')

</style>

@stop

@section('main')
<?php $page_name = 'Dashboard' ?>




@stop

@section('scripts')

@stop

