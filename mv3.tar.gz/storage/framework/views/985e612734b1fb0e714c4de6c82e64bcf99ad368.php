<?php $__env->startSection('styles'); ?>	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php $page_name = 'Generate Vouchers' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title"><?php /* ..... */ ?></h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="<?php echo e(url('voucher_prog_batches')); ?>">List generated vouchers</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->
					
					<!--form goes here -->
						<?php echo Form::open(['url' => 'invite_organ', 'method' => 'post', 'class' => 'form-horizontal']); ?>	
							

							<div class="form-group">
							<?php echo Form::label('type', 'Select voucher type', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
							<select class="form-control select2_1" name="type">						
							<option value="AL">Cereal</option>
							<option value="AR">Legume</option>
					</select>								
								</div>
								<span class="text-danger"><?php echo e($errors->first('type', ':message')); ?></span>
							</div>

							<div class="form-group">
							<?php echo Form::label('number', 'Number of vouchers', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
							<?php echo e(Form::text('number', null, ['class' => 'form-control','placeholder'=>'0'])); ?>

								</div>
								<span class="text-danger"><?php echo e($errors->first('number', ':message')); ?></span>
							</div>

							<div class="form-group margin-bottom-0">
								<div class="col-sm-offset-3 col-sm-10">
									<?php echo Form::submit('Generate Vouchers',null,'btn btn-info btn-sm ml-15'); ?>

								</div>
							</div>

				  <?php echo Form::close(); ?>


				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<!-- Demo Scripts -->
	<?php echo HTML::script('assets/scripts/form.demo.min.js'); ?>	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>