<?php $__env->startSection('main'); ?>

            
    <?php echo Form::open(['url' => 'auth/login', 'method' => 'post', 'class' => 'frm-single']); ?>

    <div class="inside">
      <div class="title"><strong>M-Voucher</strong> III</div>
      <!-- /.title -->
     <?php /*  <div class="frm-title">Login</div> */ ?>

           <?php if(session()->has('error')): ?>
                    <?php echo $__env->make('partials/error', ['type' => 'danger', 'message' => session('error')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>

           <?php if(session()->has('ok')): ?>
    <?php echo $__env->make('partials/error', ['type' => 'success', 'message' => session('ok')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endif; ?>

      <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('log', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::email('log', null, ['class' => 'frm-inp','placeholder'=>'Username'])); ?>

        <i class="fa fa-user frm-ico"></i>
        </div>
      <!-- /.frm-input -->

       <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('password', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::password('password', ['class' => 'frm-inp','placeholder'=>'Password'])); ?>

        <i class="fa fa-lock frm-ico"></i>
        </div>
      <!-- /.frm-input -->

      <div class="clearfix margin-bottom-20">
        <div class="pull-left">

       <?php /*    <div class="checkbox primary">    
                    <input id="memory" name="memory" type="checkbox">
                    <?php echo Form::label('memory', 'Remember me'); ?>

          </div> */ ?>
          <!-- /.checkbox -->
        </div>
        <!-- /.pull-left -->
        <div class="pull-right"><a href="<?php echo e(url('password/email')); ?>" class="a-link"><i class="fa fa-unlock-alt"></i>Forgot password?</a></div>
        <!-- /.pull-right -->
      </div>
      <!-- /.clearfix -->

         <div class="row small-spacing">
        <!-- /.col-sm-12 -->
        <div class="col-sm-12"><button type="submit" class="btn btn-sm btn-icon btn-icon-left btn-social-with-text btn-facebook text-white waves-effect waves-light"><i class="ico fa fa-arrow-circle-right"></i><span>Login me in</span></button></div>
        <!-- /.col-sm-6 -->
      </div>

<div class="frm-sponsors">
      <div class="row small-spacing">
       <!-- /.col-sm-12 -->
        <div class="col-sm-8"><img class="img-responsive" src="<?php echo e(asset('assets/images/sponsers.png')); ?>"></div>
         <div class="col-sm-4"><img class="img-responsive" src="<?php echo e(asset('assets/images/innovatelogo.png')); ?>"></div>
      </div></div>
      <!-- /.row -->

 <?php echo $__env->make('auth/partial/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  
    </div>
    <!-- .inside -->
    <?php echo csrf_field(); ?>

  <?php echo Form::close(); ?>               

  <!-- /.frm-single -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('auth.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>