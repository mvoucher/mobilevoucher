<?php $__env->startSection('styles'); ?>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php $page_name = 'Dashboard' ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>