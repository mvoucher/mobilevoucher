    <div class="frm-footer">
      <div class="row">
        <div class="col-sm-4"> © <?php echo e(date("Y")); ?> </div>
        <div class="col-sm-8">
        <ul id="lang" class="pull-right">
            <li class="active"><a href="#"><img width="28" height="16" alt="<?php echo e(session('locale')); ?>"  src="<?php echo asset('assets/images/flags/' . session('locale') . '.png'); ?>" /></a></li>
            <?php foreach( config('app.languages') as $user): ?>
                <?php if($user !== config('app.locale')): ?>
                  <li><a href="<?php echo url('language'); ?>/<?php echo e($user); ?>"><img width="32" height="20" alt="<?php echo e($user); ?>" src="<?php echo asset('assets/images/flags/' . $user . '.png'); ?>"></a></li>
                <?php endif; ?>
              <?php endforeach; ?>
            </ul>
            </div>
      </div>
            
      </div>
      <!-- /.footer -->