<?php $__env->startSection('main'); ?>


          <?php echo Form::open(['url' => 'password/email', 'method' => 'post', 'class' => 'frm-single']); ?>

    <div class="inside">
      <div class="title"><strong>M-Voucher</strong> III</div>
      <!-- /.title -->
      <div class="frm-title">Reset Password</div>

             <?php if(session()->has('error')): ?>
                    <?php echo $__env->make('partials/error', ['type' => 'danger', 'message' => session('error')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>

         <p class="text-center">Enter your email address and we'll send you an email with instructions to reset your password.</p>
    
         <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('email', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::email('email', null, ['class' => 'frm-inp','placeholder'=>'email Address'])); ?>

        <i class="fa fa-envelope frm-ico"></i>
        </div>
      <!-- /.frm-input -->


      <div class="row small-spacing">
        <!-- /.col-sm-12 -->
        <div class="col-sm-6"><button type="submit" class="btn btn-sm btn-icon btn-icon-left btn-social-with-text btn-facebook text-white waves-effect waves-light"><i class="ico fa fa-reply"></i><span>Send me</span></button></div>
        <!-- /.col-sm-6 -->
        <div class="col-sm-6"><a href="<?php echo e(url('/')); ?>" class="a-link"><button type="button" class="btn btn-sm btn-icon btn-icon-left btn-social-with-text btn-google-plus text-white waves-effect waves-light"><i class="ico fa fa-edit"></i>Back To Login</button></a></div>
        <!-- /.col-sm-6 -->
      </div>

       <?php echo $__env->make('auth/partial/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- /.footer -->
    </div>
    <!-- .inside -->

                        <?php echo Form::text('address', '', ['class' => 'hpet']); ?> 
<?php echo Form::close(); ?> 


  <!-- /.frm-single -->


	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>