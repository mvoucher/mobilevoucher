<?php echo $__env->make('partials/dtables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('styles'); ?>	
	<?php echo $__env->yieldContent('dtstyles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php $page_name = 'List of Organisations' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title"><?php /* ..... */ ?></h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="<?php echo e(route('organisation.create')); ?>">Invite Organisation</a></li>
							<li><a href="<?php echo e(url('organisation_invites')); ?>">List Invites</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->
					<table id="example" class="table table-striped table-bordered display" style="width:100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Username</th>
								<th>Country</th>
								<th>Telephone</th>
								<th>Email</th>
								<th>Date added</th>
								<th>View : Edit</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
						<?php foreach($organisations as $org): ?>
							<tr>
								<td><?php echo e($org->name); ?></td>
								<td><?php echo e($org->username); ?></td>
								<td><?php echo e($org->country); ?></td>
								<td><?php echo e($org->telephone); ?></td>
								<td><?php echo e($org->email); ?></td>
								<td><?php echo e(date("d-m-Y", strtotime($org->created_at))); ?></td>
								<td>   
								<div class="btn-group">
						 <a class="btn btn-primary btn-xs" href="#"><i class="fa fa-eye" title="View more"></i></a>
						<a class="btn btn-warning btn-xs" href="#"><i class="fa fa-edit" title="Edit"></i></a>
								</div></td>
								<td>
		<?php echo Form::open(['method' => 'DELETE', 'route' => ['user.destroy', $org->id]]); ?>

        <?php echo Form::destroy('Delete', 'Are you sure you want to delete this client'); ?>

        <?php echo Form::close(); ?>

								</td>
							</tr>
							<?php /* expr */ ?>
						<?php endforeach; ?>
							
						</tbody>
					</table>
				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo $__env->yieldContent('dtscripts'); ?>

	 <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: [ 0, ':visible' ]
                }
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdfHtml5',
                exportOptions: {
                    columns: [ 0, 1, 2, 3, 4, 5]
                }
            },
            'colvis'
        ]
    } );
} );
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>