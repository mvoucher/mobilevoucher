<?php $__env->startSection('main'); ?>
    

                 <?php echo Form::open(['url' => 'auth/register', 'method' => 'post', 'class' => 'frm-single','files'=>true]); ?>

    <div class="inside">
      <div class="title"><strong>M-Voucher</strong> III</div>
      <!-- /.title -->
      <?php /* <div class="frm-title">Register</div> */ ?>

  <?php if(session()->has('error')): ?>
                    <?php echo $__env->make('partials/error', ['type' => 'danger', 'message' => session('error')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?> 

        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('name', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::text('name', null, ['class' => 'frm-inp','placeholder'=>'Organisation Name'])); ?>

        <i class="fa fa-building frm-ico"></i>
        </div>
      <!-- /.frm-input -->

        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('photo', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::file('photo', null,['class'=>'frm-inp'])); ?>

        </div>
      <!-- /.frm-input -->

        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('telephone', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::text('telephone', null, ['class' => 'frm-inp','placeholder'=>'Telephone/Phonenumber'])); ?>

        <i class="fa fa-phone frm-ico"></i>
        </div>
      <!-- /.frm-input -->

        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('usertype', ':message')); ?></span>
      <div class="frm-input">
         <?php echo Form::select('usertype', $invite->role_id==1? $select_org:$select_prog,  null, ['class' => 'frm-inp','placeholder'=>'Select category' ]); ?>

        <i class="fa fa-suitcase frm-ico"></i>
        </div>
      <!-- /.frm-input -->

        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('country', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::text('country', null, ['class' => 'frm-inp','placeholder'=>'country'])); ?>

        <i class="fa fa-globe frm-ico"></i>
        </div>
      <!-- /.frm-input -->

        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('email', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::email('email', null, ['class' => 'frm-inp','placeholder'=>'email Address'])); ?>

        <i class="fa fa-envelope frm-ico"></i>
        </div>
      <!-- /.frm-input -->

       <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('username', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::text('username', null, ['class' => 'frm-inp','placeholder'=>'Username'])); ?>

        <i class="fa fa-user-secret frm-ico"></i>
        </div>
      <!-- /.frm-input -->
      
        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('password', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::password('password', ['class' => 'frm-inp','placeholder'=>'Password'])); ?>

        <i class="fa fa-lock frm-ico"></i>
        </div>
      <!-- /.frm-input -->

        <!-- /.frm-title -->
        <span class="text-danger"><?php echo e($errors->first('password_confirmation', ':message')); ?></span>
      <div class="frm-input">
        <?php echo e(Form::password('password_confirmation', ['class' => 'frm-inp','placeholder'=>'Confirm password'])); ?>

        <i class="fa fa-lock frm-ico"></i>
        </div>
      <!-- /.frm-input -->

      <div class="row small-spacing">
        <!-- /.col-sm-12 -->
        <div class="col-sm-12"><button type="submit" class="btn btn-sm btn-icon btn-icon-left btn-social-with-text btn-facebook text-white waves-effect waves-light"><i class="ico fa fa-edit"></i><span>Register Me</span></button></div>
        <!-- /.col-sm-6 -->
        <!-- /.col-sm-6 -->
      </div>
      <!-- /.row -->
      
       <?php echo $__env->make('auth/partial/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::text('invitor_role', $invite->role_id, ['class' => 'hpet']); ?>

    <?php echo Form::text('invitor_id', $invite->user_id, ['class' => 'hpet']); ?>


      <!-- /.footer -->
    </div>
    <!-- .inside -->
    <?php echo Form::text('address', '', ['class' => 'hpet']); ?>

  <?php echo Form::close(); ?>

  <!-- /.frm-single -->
          
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>