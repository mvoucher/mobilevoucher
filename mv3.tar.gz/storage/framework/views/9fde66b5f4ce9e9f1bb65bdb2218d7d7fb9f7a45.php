<?php $__env->startSection('dtstyles'); ?>
<!-- Data Tables -->
	<?php echo HTML::style('assets/plugin/datatables/media/css/dataTables.bootstrap.min.css'); ?>

	<?php echo HTML::style('assets/plugin/datatables/extensions/Responsive/css/responsive.bootstrap.min.css'); ?>

	<?php echo HTML::style('assets/plugin/datatables/buttons/buttons.dataTables.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('dtscripts'); ?>
<!-- Data Tables -->
	<?php echo HTML::script('assets/plugin/datatables/media/js/jquery.dataTables.min.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/media/js/dataTables.bootstrap.min.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/extensions/Responsive/js/dataTables.responsive.min.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/extensions/Responsive/js/responsive.bootstrap.min.js'); ?>

	
	<?php echo HTML::script('assets/plugin/datatables/buttons/dataTables.buttons.min.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/buttons/jszip.min.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/buttons/pdfmake.min.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/buttons/vfs_fonts.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/buttons/buttons.html5.min.js'); ?>

	<?php echo HTML::script('assets/plugin/datatables/buttons/buttons.colVis.min.js'); ?>



   
<?php $__env->stopSection(); ?>