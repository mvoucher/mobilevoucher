<?php $__env->startSection('styles'); ?>	
<!-- Datepicker -->
<?php echo HTML::style('assets/plugin/datepicker/css/bootstrap-datepicker.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php $page_name = 'Register Agro Dealer' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title"><?php /* ..... */ ?></h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="<?php echo e(url('dealer_of_prog')); ?>">List Dealers</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->
					
					<!--form goes here -->
						<?php echo Form::open(['url' => 'invite_organ', 'method' => 'post', 'class' => 'form-horizontal']); ?>	
							<div class="form-group">
							<?php echo Form::label('name', 'Name', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
							<?php echo e(Form::text('name', null, ['class' => 'form-control','placeholder'=>'Full Name'])); ?>

								</div>
								<span class="text-danger"><?php echo e($errors->first('name', ':message')); ?></span>
							</div>

							<div class="form-group">
								  <label class="col-sm-3 control-label" for="radios">Gender</label>
								  <div class="col-sm-5"> 
								    <div class="radio">
                   				 <?php echo Form::radio('gender', 'male', true, ['id' => 'radio1']); ?>

								<?php echo Form::label('radio1', 'Male'); ?>

							</div>
							<div class="radio">
                   				 <?php echo Form::radio('gender', 'female', false, ['id' => 'radio2']); ?>

								<?php echo Form::label('radio2', 'Feale'); ?>

							</div>  
							  </div>
							</div>

							<div class="form-group">
							<?php echo Form::label('dob', 'Date of Birth', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
								<div class="input-group">
							<?php echo e(Form::text('dob', null, ['class' => 'form-control','placeholder'=>'mm/dd/yyyy','id'=>'datepicker-autoclose'])); ?>

							<span class="input-group-addon bg-primary text-white"><i class="fa fa-calendar"></i></span>	
								</div>
								</div>
								<span class="text-danger"><?php echo e($errors->first('dob', ':message')); ?></span>
							</div>

							<div class="form-group">
							<?php echo Form::label('location', 'Location', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
							<?php echo e(Form::text('location', null, ['class' => 'form-control','placeholder'=>'Location'])); ?>

								</div>
								<span class="text-danger"><?php echo e($errors->first('location', ':message')); ?></span>
							</div>

							<div class="form-group">
							<?php echo Form::label('mm_number', 'Mobile Money number', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
							<?php echo e(Form::text('mm_number', null, ['class' => 'form-control','placeholder'=>'2567xxxxxxxx'])); ?>

								</div>
								<span class="text-danger"><?php echo e($errors->first('mm_number', ':message')); ?></span>
							</div>

							<div class="form-group margin-bottom-0">
								<div class="col-sm-offset-3 col-sm-10">
									<?php echo Form::submit('Save',null,'btn btn-info btn-sm ml-15'); ?>

								</div>
							</div>
				  <?php echo Form::close(); ?>


				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<!-- Datepicker -->
	<?php echo HTML::script('assets/plugin/datepicker/js/bootstrap-datepicker.min.js'); ?>	

	<!-- Demo Scripts -->
	<?php echo HTML::script('assets/scripts/form.demo.min.js'); ?>	
<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>