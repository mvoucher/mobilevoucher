<?php $__env->startSection('styles'); ?>	
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php $page_name = 'Create Programme' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title"><?php /* ..... */ ?></h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="<?php echo e(url('programme_of_org')); ?>">List Programmes</a></li>
							<li><a href="<?php echo e(url('program_invites')); ?>">List Invites</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->
					
					<!--form goes here -->
					<?php echo Form::open(['url' => 'invite_program', 'method' => 'post', 'class' => 'form-horizontal']); ?>	
							<div class="form-group">
							<?php echo Form::label('name', 'Name of Programme', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
							<?php echo e(Form::text('name', null, ['class' => 'form-control','placeholder'=>'Programme Name'])); ?>

								</div>
								<span class="text-danger"><?php echo e($errors->first('name', ':message')); ?></span>
							</div>

							<div class="form-group">
							 <?php echo Form::label('email', 'Email address', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
								  <?php echo e(Form::email('email', null, ['class' => 'form-control','placeholder'=>'email Address'])); ?>

								</div>
								<span class="text-danger"><?php echo e($errors->first('email', ':message')); ?></span>
							</div>

							<div class="form-group margin-bottom-0">
								<div class="col-sm-offset-3 col-sm-10">
									<?php echo Form::submit('Send Invitation',null,'btn btn-info btn-sm ml-15'); ?>

								</div>
							</div>

    <?php echo Form::text('role_id', auth()->user()->role_id, ['class' => 'hpet']); ?>

				  <?php echo Form::close(); ?>


				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>