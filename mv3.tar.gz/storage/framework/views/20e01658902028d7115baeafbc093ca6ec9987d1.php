<?php $__env->startSection('styles'); ?>	
<!-- Datepicker -->
<?php echo HTML::style('assets/plugin/datepicker/css/bootstrap-datepicker.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php $page_name = 'Register beneficiary' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title"><?php /* ..... */ ?></h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="<?php echo e(url('beneficiary_of_prog')); ?>">List Beneficiaries</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->
					
					<!--form goes here -->
						<?php echo Form::open(['url' => 'importExcel', 'method' => 'post', 'class' => '','files'=>true]); ?>

							<div class="form-group">
							<?php echo Form::label('import_file', 'Attach an excel file', ['class' => 'col-sm-3 control-label'] ); ?>

								<div class="col-sm-5">
							 <?php echo e(Form::file('import_file', null,['class'=>''])); ?>

								</div>
								<span class="text-danger"><?php echo e($errors->first('import_file', ':message')); ?></span>
							</div>


							<div class="form-group margin-bottom-0">
								<div class="col-sm-offset-3 col-sm-10">
									<?php echo Form::submit('Upload file',null,'btn btn-info btn-sm'); ?>

								</div>
							</div>
				  <?php echo Form::close(); ?>


				  	<div class="container">

		<a href="<?php echo e(URL::to('downloadExcel/xls')); ?>"><button class="btn btn-success">Download Excel xls</button></a>

		<a href="<?php echo e(URL::to('downloadExcel/xlsx')); ?>"><button class="btn btn-success">Download Excel xlsx</button></a>

		<a href="<?php echo e(URL::to('downloadExcel/csv')); ?>"><button class="btn btn-success">Download CSV</button></a>
		<a href="<?php echo e(URL::to('exportPDF')); ?>"><button class="btn btn-success">Download PDF</button></a>


	</div>

				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<!-- Datepicker -->
	<?php echo HTML::script('assets/plugin/datepicker/js/bootstrap-datepicker.min.js'); ?>	

	<!-- Demo Scripts -->
	<?php echo HTML::script('assets/scripts/form.demo.min.js'); ?>	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>