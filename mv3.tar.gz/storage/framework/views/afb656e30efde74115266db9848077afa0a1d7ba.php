<?php echo $__env->make('partials/dtables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('styles'); ?>	
	<?php echo $__env->yieldContent('dtstyles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php $page_name = 'Voucher Types' ?>

<div class="row small-spacing">
		<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title"><?php /* ..... */ ?></h4>
					<!-- /.box-title -->
					<div class="dropdown js__drop_down">
						<a href="#" class="dropdown-icon glyphicon glyphicon-option-vertical js__drop_down_button"></a>
						<ul class="sub-menu">
							<li><a href="<?php echo e(route('voucher.create')); ?>">Create New Type</a></li>
						</ul>
						<!-- /.sub-menu -->
					</div>
					<!-- /.dropdown js__dropdown -->

					 <?php if(session()->has('ok')): ?>
    <?php echo $__env->make('partials/error', ['type' => 'success', 'message' => session('ok')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endif; ?>

					<table id="example" class="table table-striped table-bordered display" style="width:100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Color</th>
								<th>Value</th>
								<th>View : Edit</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
						<?php foreach($voucher_types as $voucher_type): ?>
							<tr>
								<td><?php echo e($voucher_type->name); ?></td>
								<td><?php echo e($voucher_type->color); ?></td>
								<td><?php echo e($voucher_type->value); ?></td>
								<td>   
								<div class="btn-group">
						 <a class="btn btn-primary btn-xs" href="#"><i class="fa fa-eye" title="View more"></i></a>
						<a class="btn btn-warning btn-xs" href="#"><i class="fa fa-edit" title="Edit"></i></a>
								</div></td>
								<td>
		<?php echo Form::open(['method' => 'DELETE', 'route' => ['user.destroy', $voucher_type->id]]); ?>

        <?php echo Form::destroy('Delete', 'Are you sure you want to delete this voucher type'); ?>

        <?php echo Form::close(); ?>

								</td>
							</tr>
						<?php endforeach; ?>
							
						</tbody>
					</table>
				</div>
				<!-- /.box-content -->
			</div>
			<!-- /.col-xs-12 -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo $__env->yieldContent('dtscripts'); ?>

	 <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: [ 0, ':visible' ]
                }
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdfHtml5',
                exportOptions: {
                    columns: [ 0, 1, 2, 3]
                }
            },
            'colvis'
        ]
    } );
} );
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>