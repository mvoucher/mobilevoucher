<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Programvouchertype extends Model  {

	
	protected $table = 'user_vouchertype';

	

}
