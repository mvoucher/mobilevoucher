<?php


phpinfo();


?>